"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getCurrentTimestamp = getCurrentTimestamp;
function getCurrentTimestamp() {
    return Math.ceil(new Date().getTime() / 1000);
}
//# sourceMappingURL=getCurrentTimestamp.js.map