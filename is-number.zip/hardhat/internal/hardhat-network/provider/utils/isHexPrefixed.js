"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isHexPrefixed = isHexPrefixed;
function isHexPrefixed(value) {
    return value.toLowerCase().startsWith("0x");
}
//# sourceMappingURL=isHexPrefixed.js.map