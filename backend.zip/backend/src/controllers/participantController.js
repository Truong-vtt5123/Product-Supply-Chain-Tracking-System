const Participant = require(
  "../models/Participant"
);

const User = require(
  "../models/User"
);

const {
  registerParticipantOnBlockchain,
} = require(
  "../services/blockchainService"
);


// ==========================================
// CREATE PARTICIPANT
// POST /api/participants
// ADMIN ONLY
// ==========================================

const createParticipant = async (
  req,
  res
) => {
  try {

    const {
      name,
      walletAddress,
      participantType,
      userId,
    } = req.body;


    // ======================================
    // 1. KIỂM TRA DỮ LIỆU
    // ======================================

    if (
      !name ||
      !walletAddress ||
      !participantType
    ) {
      return res.status(400).json({
        success: false,
        message:
          "Name, walletAddress and participantType are required",
      });
    }


    const allowedTypes = [
      "manufacturer",
      "distributor",
      "seller",
    ];


    if (
      !allowedTypes.includes(
        participantType
      )
    ) {
      return res.status(400).json({
        success: false,
        message:
          "Invalid participant type",
      });
    }


    const normalizedWallet =
      walletAddress.toLowerCase();


    // ======================================
    // 2. KIỂM TRA WALLET ĐÃ TỒN TẠI
    // ======================================

    const existingParticipant =
      await Participant.findOne({
        walletAddress:
          normalizedWallet,
      });


    if (existingParticipant) {
      return res.status(409).json({
        success: false,
        message:
          "Wallet is already registered",
      });
    }


    // ======================================
    // 3. TÌM USER NẾU CÓ userId
    // ======================================

    let user = null;


    if (userId) {

      user =
        await User.findById(
          userId
        );


      if (!user) {
        return res.status(404).json({
          success: false,
          message:
            "User not found",
        });
      }
    }


    // ======================================
    // 4. GHI PARTICIPANT LÊN BLOCKCHAIN
    // ======================================

    console.log(
      "Registering participant on blockchain..."
    );


    const blockchainResult =
      await registerParticipantOnBlockchain(
        normalizedWallet,
        name,
        participantType
      );


    console.log(
      "Blockchain transaction:",
      blockchainResult.transactionHash
    );


    // ======================================
    // 5. LƯU VÀO MONGODB
    // ======================================

    const participant =
      await Participant.create({

        name,

        walletAddress:
          normalizedWallet,

        participantType,

        user:
          user
            ? user._id
            : null,

        blockchainRegistered:
          true,

        transactionHash:
          blockchainResult
            .transactionHash,
      });


    // ======================================
    // 6. NẾU CÓ USER
    // CẬP NHẬT ROLE + WALLET
    // ======================================

    if (user) {

      user.role =
        participantType;

      user.walletAddress =
        normalizedWallet;

      await user.save();
    }


    // ======================================
    // 7. TRẢ KẾT QUẢ
    // ======================================

    res.status(201).json({

      success: true,

      message:
        "Participant registered on MongoDB and Blockchain",

      participant,

      blockchain: {
        transactionHash:
          blockchainResult
            .transactionHash,

        blockNumber:
          blockchainResult
            .blockNumber,
      },
    });

  } catch (error) {

    console.error(
      "Create participant error:",
      error
    );


    res.status(500).json({

      success: false,

      message:
        error.reason ||
        error.shortMessage ||
        error.message ||
        "Unable to create participant",
    });
  }
};


// ==========================================
// GET ALL PARTICIPANTS
// ==========================================

const getParticipants = async (
  req,
  res
) => {
  try {

    const participants =
      await Participant.find()

        .populate(
          "user",
          "name email role walletAddress"
        )

        .sort({
          createdAt: -1,
        });


    res.json({

      success: true,

      count:
        participants.length,

      participants,
    });

  } catch (error) {

    res.status(500).json({

      success: false,

      message:
        "Unable to get participants",
    });
  }
};


// ==========================================
// GET ONE PARTICIPANT
// ==========================================

const getParticipantById = async (
  req,
  res
) => {
  try {

    const participant =
      await Participant.findById(
        req.params.id
      ).populate(
        "user",
        "name email role walletAddress"
      );


    if (!participant) {

      return res.status(404).json({

        success: false,

        message:
          "Participant not found",
      });
    }


    res.json({

      success: true,

      participant,
    });

  } catch (error) {

    res.status(500).json({

      success: false,

      message:
        "Unable to get participant",
    });
  }
};


module.exports = {

  createParticipant,

  getParticipants,

  getParticipantById,
};