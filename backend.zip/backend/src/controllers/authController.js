const User = require("../models/User");
const generateToken =
  require("../utils/generateToken");


// ==========================================
// REGISTER
// POST /api/auth/register
// ==========================================

const register = async (req, res) => {
  try {
    const {
      name,
      email,
      password,
    } = req.body;


    if (
      !name ||
      !email ||
      !password
    ) {
      return res.status(400).json({
        success: false,
        message:
          "Name, email and password are required.",
      });
    }


    if (password.length < 6) {
      return res.status(400).json({
        success: false,
        message:
          "Password must be at least 6 characters.",
      });
    }


    const normalizedEmail =
      email.toLowerCase().trim();


    const existingUser =
      await User.findOne({
        email: normalizedEmail,
      });


    if (existingUser) {
      return res.status(400).json({
        success: false,
        message:
          "Email is already registered.",
      });
    }


    // Người đăng ký luôn là USER
    // Không lấy role từ req.body
    const user = await User.create({
      name: name.trim(),
      email: normalizedEmail,
      password,
      role: "user",
    });


    const token =
      generateToken(user._id);


    return res.status(201).json({
      success: true,

      message:
        "Account registered successfully.",

      token,

      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        walletAddress:
          user.walletAddress,
      },
    });

  } catch (error) {
    console.error(
      "Register error:",
      error
    );

    return res.status(500).json({
      success: false,
      message:
        "Unable to register account.",
    });
  }
};


// ==========================================
// LOGIN
// POST /api/auth/login
// ==========================================

const login = async (req, res) => {
  try {
    const {
      email,
      password,
    } = req.body;


    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message:
          "Email and password are required.",
      });
    }


    const user =
      await User.findOne({
        email:
          email.toLowerCase().trim(),
      });


    if (!user) {
      return res.status(401).json({
        success: false,
        message:
          "Invalid email or password.",
      });
    }


    if (user.isActive === false) {
      return res.status(403).json({
        success: false,
        message:
          "This account has been disabled.",
      });
    }


    const passwordCorrect =
      await user.comparePassword(
        password
      );


    if (!passwordCorrect) {
      return res.status(401).json({
        success: false,
        message:
          "Invalid email or password.",
      });
    }


    const token =
      generateToken(user._id);


    return res.json({
      success: true,

      token,

      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        walletAddress:
          user.walletAddress,
      },
    });

  } catch (error) {
    console.error(
      "Login error:",
      error
    );

    return res.status(500).json({
      success: false,
      message:
        "Unable to login.",
    });
  }
};


// ==========================================
// GET CURRENT USER
// GET /api/auth/me
// ==========================================

const getMe = async (req, res) => {
  try {
    const user =
      await User.findById(
        req.user._id
      ).select("-password");


    if (!user) {
      return res.status(404).json({
        success: false,
        message:
          "User not found.",
      });
    }


    return res.json({
      success: true,
      user,
    });

  } catch (error) {
    console.error(
      "Get me error:",
      error
    );

    return res.status(500).json({
      success: false,
      message:
        "Unable to load user.",
    });
  }
};


module.exports = {
  register,
  login,
  getMe,
};