const Product = require(
  "../models/Product"
);

const Transfer = require(
  "../models/Transfer"
);

const {
  getBlockchainProduct,
  getBlockchainProductHistory,
} = require(
  "../services/blockchainService"
);


// ==========================================
// TRACK PRODUCT
// GET /api/tracking/:productId
// ==========================================

const trackProduct = async (
  req,
  res
) => {

  try {

    // ======================================
    // 1. TÌM PRODUCT TRONG MONGODB
    // ======================================

    const product =
      await Product.findOne({

        productId:
          req.params.productId,

      })

        .populate(
          "manufacturer",
          "name walletAddress participantType"
        )

        .populate(
          "currentOwner",
          "name walletAddress participantType"
        );


    if (!product) {

      return res.status(404).json({

        success: false,

        message:
          "Product not found",
      });
    }


    // ======================================
    // 2. LẤY TRANSFER HISTORY TỪ MONGODB
    // ======================================

    const transfers =
      await Transfer.find({

        productId:
          product.productId,

      })

        .populate(
          "from",
          "name walletAddress participantType"
        )

        .populate(
          "to",
          "name walletAddress participantType"
        )

        .sort({
          createdAt: 1,
        });


    // ======================================
    // 3. CHUẨN BỊ BLOCKCHAIN DATA
    // ======================================

    let blockchain = null;


    // ======================================
    // 4. NẾU PRODUCT CÓ BLOCKCHAIN ID
    // THÌ ĐỌC SMART CONTRACT
    // ======================================

    if (
      product.blockchainProductId
    ) {

      const blockchainProduct =
        await getBlockchainProduct(

          product.blockchainProductId
        );


      const blockchainHistory =
        await getBlockchainProductHistory(

          product.blockchainProductId
        );


      // ====================================
      // 5. CHUYỂN BIGINT -> STRING
      // để JSON có thể trả về browser
      // ====================================

      blockchain = {

        id:
          blockchainProduct
            .id
            .toString(),

        productCode:
          blockchainProduct
            .productCode,

        name:
          blockchainProduct
            .name,

        manufacturer:
          blockchainProduct
            .manufacturer,

        currentHolder:
          blockchainProduct
            .currentHolder,

        status:
          blockchainProduct
            .status
            .toString(),

        createdAt:
          blockchainProduct
            .createdAt
            .toString(),


        transferHistory:
          blockchainHistory.map(
            (item) => ({

              from:
                item.from,

              to:
                item.to,

              fromRole:
                item.fromRole
                  .toString(),

              toRole:
                item.toRole
                  .toString(),

              timestamp:
                item.timestamp
                  .toString(),
            })
          ),
      };
    }


    // ======================================
    // 6. TRẢ CẢ MONGODB + BLOCKCHAIN
    // ======================================

    res.json({

      success: true,


      mongoDB: {

        product: {

          productId:
            product.productId,

          blockchainProductId:
            product.blockchainProductId,

          name:
            product.name,

          description:
            product.description,

          status:
            product.status,

          manufacturer:
            product.manufacturer,

          currentOwner:
            product.currentOwner,

          transactionHash:
            product.transactionHash,

          createdAt:
            product.createdAt,
        },


        transferHistory:
          transfers,


        totalTransfers:
          transfers.length,
      },


      blockchain,
    });


  } catch (error) {

    console.error(
      "Tracking error:",
      error
    );


    res.status(500).json({

      success: false,

      message:
        error.reason ||
        error.shortMessage ||
        error.message ||
        "Unable to track product",
    });
  }
};


module.exports = {
  trackProduct,
};