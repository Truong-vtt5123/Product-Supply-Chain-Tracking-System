const Product = require("../models/Product");
const Participant = require("../models/Participant");
const Transfer = require("../models/Transfer");

const {
  registerParticipantOnBlockchain,
  getParticipantFromBlockchain,
  registerProductOnBlockchain,
  transferProductOnBlockchain,
} = require("../services/blockchainService");

// ======================================================
// HELPERS
// ======================================================

const generateProductId = (prefix = "PRD") => {
  return `${prefix}-${Date.now()}-${Math.floor(
    Math.random() * 100000
  )}`;
};

const getUserId = (req) => {
  return req.user?._id || req.user?.id || null;
};

const getParticipantType = (participant) => {
  return String(
    participant?.participantType ||
      participant?.type ||
      ""
  )
    .trim()
    .toLowerCase();
};

const getBlockchainProductId = (result) => {
  if (!result) return null;

  const value =
    result.blockchainProductId ??
    result.productId ??
    result.id ??
    null;

  if (
    value === null ||
    value === undefined
  ) {
    return null;
  }

  return value.toString();
};

const getTransactionHash = (result) => {
  return (
    result?.transactionHash ||
    result?.txHash ||
    result?.hash ||
    null
  );
};

// ======================================================
// KIỂM TRA MANUFACTURER TRÊN BLOCKCHAIN
// ======================================================

const ensureManufacturerOnBlockchain =
  async (manufacturer) => {
    if (!manufacturer) {
      throw new Error(
        "Manufacturer không tồn tại."
      );
    }

    if (!manufacturer.walletAddress) {
      throw new Error(
        "Manufacturer chưa có địa chỉ ví Blockchain."
      );
    }

    let existsOnBlockchain = false;

    // --------------------------------------------------
    // 1. KIỂM TRA TRỰC TIẾP BLOCKCHAIN
    // --------------------------------------------------

    try {
      const participant =
        await getParticipantFromBlockchain(
          manufacturer.walletAddress
        );

      console.log(
        "Blockchain participant:",
        participant
      );

      /*
       * SupplyChain.sol:
       *
       * None         = 0
       * Manufacturer = 1
       * Distributor  = 2
       * Seller       = 3
       */

      const roleValue =
        participant?.role ??
        participant?.[2] ??
        0;

      const role = Number(roleValue);

      const activeValue =
        participant?.isActive ??
        participant?.[3] ??
        false;

      const isActive =
        activeValue === true;

      console.log(
        "Manufacturer Blockchain role:",
        role
      );

      console.log(
        "Manufacturer active:",
        isActive
      );

      existsOnBlockchain =
        role === 1 && isActive;
    } catch (error) {
      console.log(
        "Manufacturer chưa tồn tại trên Blockchain:",
        error.message
      );

      existsOnBlockchain = false;
    }

    // --------------------------------------------------
    // 2. NẾU CHƯA CÓ → ADMIN ĐĂNG KÝ
    // --------------------------------------------------

    if (!existsOnBlockchain) {
      console.log(
        "Đang đăng ký Manufacturer lên Blockchain..."
      );

      const result =
        await registerParticipantOnBlockchain(
          manufacturer.walletAddress,
          manufacturer.name ||
            "Manufacturer",
          "manufacturer"
        );

      console.log(
        "Manufacturer Blockchain TX:",
        result?.transactionHash
      );

      manufacturer.blockchainRegistered =
        true;

      if (
        manufacturer.schema?.path(
          "transactionHash"
        )
      ) {
        manufacturer.transactionHash =
          result?.transactionHash || null;
      }

      await manufacturer.save();

      console.log(
        "Manufacturer đã được đăng ký Blockchain."
      );

      return result;
    }

    // --------------------------------------------------
    // 3. ĐÃ CÓ TRÊN CHAIN → ĐỒNG BỘ MONGODB
    // --------------------------------------------------

    if (!manufacturer.blockchainRegistered) {
      manufacturer.blockchainRegistered =
        true;

      await manufacturer.save();
    }

    console.log(
      "Manufacturer đã tồn tại trên Blockchain."
    );

    return null;
  };

// ======================================================
// GET ALL PRODUCTS
// GET /api/products
// ======================================================

const getProducts = async (req, res) => {
  try {
    const products = await Product.find()
      .populate(
        "manufacturer",
        "name type participantType walletAddress blockchainRegistered"
      )
      .populate(
        "currentOwner",
        "name type participantType walletAddress blockchainRegistered"
      )
      .populate(
        "ownerUser",
        "name email role"
      )
      .populate(
        "verificationReviewedBy",
        "name email role"
      )
      .sort({
        createdAt: -1,
      });

    return res.status(200).json({
      success: true,
      count: products.length,
      products,
    });
  } catch (error) {
    console.error(
      "GET PRODUCTS ERROR:",
      error
    );

    return res.status(500).json({
      success: false,
      message:
        error.message ||
        "Không thể lấy danh sách sản phẩm.",
    });
  }
};

// ======================================================
// GET ONE PRODUCT
// GET /api/products/:productId
// ======================================================

const getProduct = async (req, res) => {
  try {
    const { productId } = req.params;

    let product = await Product.findOne({
      productId,
    })
      .populate(
        "manufacturer",
        "name type participantType walletAddress blockchainRegistered"
      )
      .populate(
        "currentOwner",
        "name type participantType walletAddress blockchainRegistered"
      )
      .populate(
        "ownerUser",
        "name email role"
      )
      .populate(
        "verificationReviewedBy",
        "name email role"
      );

    // Cho phép tìm bằng MongoDB _id
    if (
      !product &&
      /^[0-9a-fA-F]{24}$/.test(productId)
    ) {
      product = await Product.findById(
        productId
      )
        .populate(
          "manufacturer",
          "name type participantType walletAddress blockchainRegistered"
        )
        .populate(
          "currentOwner",
          "name type participantType walletAddress blockchainRegistered"
        )
        .populate(
          "ownerUser",
          "name email role"
        )
        .populate(
          "verificationReviewedBy",
          "name email role"
        );
    }

    if (!product) {
      return res.status(404).json({
        success: false,
        message:
          "Không tìm thấy sản phẩm.",
      });
    }

    return res.status(200).json({
      success: true,
      product,
    });
  } catch (error) {
    console.error(
      "GET PRODUCT ERROR:",
      error
    );

    return res.status(500).json({
      success: false,
      message:
        error.message ||
        "Không thể lấy thông tin sản phẩm.",
    });
  }
};

// ======================================================
// ADMIN / MANUFACTURER TẠO PRODUCT
// POST /api/products
// ======================================================

const createProduct = async (req, res) => {
  try {
    const {
      name,
      description,
      manufacturerId,
      metadata,
    } = req.body;

    // --------------------------------------------------
    // NAME
    // --------------------------------------------------

    if (!name || !name.trim()) {
      return res.status(400).json({
        success: false,
        message:
          "Vui lòng nhập tên sản phẩm.",
      });
    }

    // --------------------------------------------------
    // MANUFACTURER
    // --------------------------------------------------

    if (!manufacturerId) {
      return res.status(400).json({
        success: false,
        message:
          "Vui lòng chọn nhà sản xuất.",
      });
    }

    const manufacturer =
      await Participant.findById(
        manufacturerId
      );

    if (!manufacturer) {
      return res.status(404).json({
        success: false,
        message:
          "Không tìm thấy nhà sản xuất.",
      });
    }

    const manufacturerType =
      getParticipantType(manufacturer);

    if (
      manufacturerType !==
      "manufacturer"
    ) {
      return res.status(400).json({
        success: false,
        message:
          "Participant được chọn không phải Manufacturer.",
      });
    }

    if (!manufacturer.walletAddress) {
      return res.status(400).json({
        success: false,
        message:
          "Manufacturer chưa có địa chỉ ví Blockchain.",
      });
    }

    // --------------------------------------------------
    // PRODUCT ID
    // --------------------------------------------------

    const productId =
      generateProductId("PRD");

    // --------------------------------------------------
    // ĐẢM BẢO MANUFACTURER CÓ TRÊN BLOCKCHAIN
    // --------------------------------------------------

    try {
      await ensureManufacturerOnBlockchain(
        manufacturer
      );
    } catch (error) {
      console.error(
        "ENSURE MANUFACTURER ERROR:",
        error
      );

      return res.status(500).json({
        success: false,
        message:
          error.message ||
          "Không thể đăng ký Manufacturer trên Blockchain.",
      });
    }

    // --------------------------------------------------
    // REGISTER PRODUCT BLOCKCHAIN
    // --------------------------------------------------

    let blockchainResult;

    try {
      blockchainResult =
        await registerProductOnBlockchain(
          manufacturer.walletAddress,
          productId,
          name.trim()
        );
    } catch (blockchainError) {
      console.error(
        "REGISTER PRODUCT BLOCKCHAIN ERROR:",
        blockchainError
      );

      return res.status(500).json({
        success: false,
        message:
          blockchainError.shortMessage ||
          blockchainError.reason ||
          blockchainError.message ||
          "Không thể đăng sản phẩm lên Blockchain.",
      });
    }

    const blockchainProductId =
      getBlockchainProductId(
        blockchainResult
      );

    const transactionHash =
      getTransactionHash(
        blockchainResult
      );

    if (!blockchainProductId) {
      return res.status(500).json({
        success: false,
        message:
          "Blockchain transaction thành công nhưng không lấy được Product ID.",
      });
    }

    if (!transactionHash) {
      return res.status(500).json({
        success: false,
        message:
          "Blockchain transaction thành công nhưng không lấy được Transaction Hash.",
      });
    }

    // --------------------------------------------------
    // CREATE MONGODB PRODUCT
    // --------------------------------------------------

    const product =
      await Product.create({
        productId,

        blockchainProductId,

        name: name.trim(),

        manufacturerName:
          manufacturer.name || "",

        description:
          description?.trim() || "",

        productImage: null,

        ownerUser: null,

        manufacturer:
          manufacturer._id,

        currentOwner:
          manufacturer._id,

        blockchainRegistered: true,

        transactionHash,

        status: "manufactured",

        metadata:
          metadata &&
          typeof metadata === "object"
            ? metadata
            : {},

        verificationStatus:
          "approved",

        verificationReviewedAt:
          new Date(),

        verificationNote:
          "Sản phẩm được tạo trực tiếp và đăng ký Blockchain.",
      });

    const populatedProduct =
      await Product.findById(product._id)
        .populate(
          "manufacturer",
          "name type participantType walletAddress blockchainRegistered"
        )
        .populate(
          "currentOwner",
          "name type participantType walletAddress blockchainRegistered"
        );

    return res.status(201).json({
      success: true,

      message:
        "Tạo sản phẩm và đăng Blockchain thành công.",

      transactionHash,

      blockchainProductId,

      product: populatedProduct,
    });
  } catch (error) {
    console.error(
      "CREATE PRODUCT ERROR:",
      error
    );

    return res.status(500).json({
      success: false,
      message:
        error.message ||
        "Không thể tạo sản phẩm.",
    });
  }
};

// ======================================================
// USER THƯỜNG ĐĂNG SẢN PHẨM
// POST /api/products/user
//
// multipart/form-data
// productImage bắt buộc
//
// CHỈ LƯU MONGODB.
// ======================================================

const createUserProduct = async (
  req,
  res
) => {
  try {
    const userId = getUserId(req);

    if (!userId) {
      return res.status(401).json({
        success: false,
        message:
          "Bạn chưa đăng nhập.",
      });
    }

    const {
      name,
      manufacturerName,
      description,
      category,
      origin,
    } = req.body;

    // --------------------------------------------------
    // NAME
    // --------------------------------------------------

    if (!name || !name.trim()) {
      return res.status(400).json({
        success: false,
        message:
          "Vui lòng nhập tên sản phẩm.",
      });
    }

    // --------------------------------------------------
    // MANUFACTURER NAME
    // --------------------------------------------------

    if (
      !manufacturerName ||
      !manufacturerName.trim()
    ) {
      return res.status(400).json({
        success: false,
        message:
          "Vui lòng nhập tên nhà sản xuất / cơ sở sản xuất.",
      });
    }

    // --------------------------------------------------
    // IMAGE
    // --------------------------------------------------

    if (!req.file) {
      return res.status(400).json({
        success: false,
        message:
          "Vui lòng chọn hình ảnh sản phẩm.",
      });
    }

    // --------------------------------------------------
    // CREATE PRODUCT
    // --------------------------------------------------

    const productId =
      generateProductId("USR");

    const productImage =
      `/uploads/products/${req.file.filename}`;

    const product =
      await Product.create({
        productId,

        blockchainProductId: null,

        name: name.trim(),

        manufacturerName:
          manufacturerName.trim(),

        description:
          description?.trim() || "",

        productImage,

        ownerUser: userId,

        manufacturer: null,

        currentOwner: null,

        blockchainRegistered: false,

        transactionHash: null,

        status: "manufactured",

        metadata: {
          category:
            category?.trim() || "",

          origin:
            origin?.trim() || "",
        },

        verificationStatus:
          "not_requested",

        verificationRequestedAt:
          null,

        verificationReviewedAt:
          null,

        verificationReviewedBy:
          null,

        verificationNote: "",
      });

    const populatedProduct =
      await Product.findById(
        product._id
      ).populate(
        "ownerUser",
        "name email role"
      );

    return res.status(201).json({
      success: true,

      message:
        "Đăng sản phẩm thành công. Sản phẩm chưa được xác minh Blockchain.",

      product: populatedProduct,
    });
  } catch (error) {
    console.error(
      "CREATE USER PRODUCT ERROR:",
      error
    );

    return res.status(500).json({
      success: false,

      message:
        error.message ||
        "Không thể đăng sản phẩm.",
    });
  }
};

// ======================================================
// USER - MY PRODUCTS
// GET /api/products/my-products
// ======================================================

const getMyProducts = async (
  req,
  res
) => {
  try {
    const userId = getUserId(req);

    if (!userId) {
      return res.status(401).json({
        success: false,
        message:
          "Bạn chưa đăng nhập.",
      });
    }

    const products = await Product.find({
      ownerUser: userId,
    })
      .populate(
        "manufacturer",
        "name type participantType walletAddress blockchainRegistered"
      )
      .populate(
        "currentOwner",
        "name type participantType walletAddress blockchainRegistered"
      )
      .populate(
        "verificationReviewedBy",
        "name email role"
      )
      .sort({
        createdAt: -1,
      });

    return res.status(200).json({
      success: true,
      count: products.length,
      products,
    });
  } catch (error) {
    console.error(
      "GET MY PRODUCTS ERROR:",
      error
    );

    return res.status(500).json({
      success: false,
      message:
        error.message ||
        "Không thể lấy sản phẩm của bạn.",
    });
  }
};

// ======================================================
// USER GỬI YÊU CẦU XÁC MINH
// POST /api/products/:productId/request-verification
// ======================================================

const requestBlockchainVerification =
  async (req, res) => {
    try {
      const userId = getUserId(req);

      const { productId } =
        req.params;

      if (!userId) {
        return res.status(401).json({
          success: false,
          message:
            "Bạn chưa đăng nhập.",
        });
      }

      const product =
        await Product.findOne({
          productId,
        });

      if (!product) {
        return res.status(404).json({
          success: false,
          message:
            "Không tìm thấy sản phẩm.",
        });
      }

      // Chỉ owner mới được gửi
      if (
        !product.ownerUser ||
        product.ownerUser.toString() !==
          userId.toString()
      ) {
        return res.status(403).json({
          success: false,

          message:
            "Bạn không có quyền gửi yêu cầu cho sản phẩm này.",
        });
      }

      if (
        product.blockchainRegistered
      ) {
        return res.status(400).json({
          success: false,

          message:
            "Sản phẩm đã được xác minh Blockchain.",
        });
      }

      if (
        product.verificationStatus ===
        "pending"
      ) {
        return res.status(400).json({
          success: false,

          message:
            "Yêu cầu xác minh đang chờ Admin xử lý.",
        });
      }

      product.verificationStatus =
        "pending";

      product.verificationRequestedAt =
        new Date();

      product.verificationReviewedAt =
        null;

      product.verificationReviewedBy =
        null;

      product.verificationNote = "";

      await product.save();

      const updatedProduct =
        await Product.findById(
          product._id
        ).populate(
          "ownerUser",
          "name email role"
        );

      return res.status(200).json({
        success: true,

        message:
          "Đã gửi yêu cầu xác minh Blockchain cho Admin.",

        product: updatedProduct,
      });
    } catch (error) {
      console.error(
        "REQUEST VERIFICATION ERROR:",
        error
      );

      return res.status(500).json({
        success: false,

        message:
          error.message ||
          "Không thể gửi yêu cầu xác minh.",
      });
    }
  };

// ======================================================
// ADMIN - GET PENDING VERIFICATION REQUESTS
// GET /api/products/admin/verification-requests
// ======================================================

const getVerificationRequests =
  async (req, res) => {
    try {
      const products =
        await Product.find({
          verificationStatus:
            "pending",

          blockchainRegistered:
            false,
        })
          .populate(
            "ownerUser",
            "name email role"
          )
          .populate(
            "manufacturer",
            "name type participantType walletAddress blockchainRegistered"
          )
          .populate(
            "currentOwner",
            "name type participantType walletAddress blockchainRegistered"
          )
          .sort({
            verificationRequestedAt:
              1,
          });

      return res.status(200).json({
        success: true,
        count: products.length,
        products,
      });
    } catch (error) {
      console.error(
        "GET VERIFICATION REQUESTS ERROR:",
        error
      );

      return res.status(500).json({
        success: false,

        message:
          error.message ||
          "Không thể lấy danh sách yêu cầu xác minh.",
      });
    }
  };

// ======================================================
// ADMIN - APPROVE + REGISTER BLOCKCHAIN
//
// POST
// /api/products/:productId/approve-verification
//
// BODY:
// {
//   manufacturerId: "..."
// }
// ======================================================

const approveBlockchainVerification =
  async (req, res) => {
    try {
      const adminId =
        getUserId(req);

      const { productId } =
        req.params;

      const { manufacturerId } =
        req.body || {};

      // --------------------------------------------------
      // AUTH
      // --------------------------------------------------

      if (!adminId) {
        return res.status(401).json({
          success: false,
          message:
            "Bạn chưa đăng nhập.",
        });
      }

      if (
        req.user?.role !== "admin"
      ) {
        return res.status(403).json({
          success: false,

          message:
            "Chỉ Admin mới có quyền phê duyệt xác minh Blockchain.",
        });
      }

      // --------------------------------------------------
      // MANUFACTURER ID
      // --------------------------------------------------

      if (!manufacturerId) {
        return res.status(400).json({
          success: false,

          message:
            "Vui lòng chọn Manufacturer Blockchain.",
        });
      }

      // --------------------------------------------------
      // PRODUCT
      // --------------------------------------------------

      const product =
        await Product.findOne({
          productId,
        });

      if (!product) {
        return res.status(404).json({
          success: false,

          message:
            "Không tìm thấy sản phẩm.",
        });
      }

      if (
        product.blockchainRegistered
      ) {
        return res.status(400).json({
          success: false,

          message:
            "Sản phẩm này đã được đăng ký Blockchain.",
        });
      }

      if (
        product.verificationStatus !==
        "pending"
      ) {
        return res.status(400).json({
          success: false,

          message:
            "Sản phẩm không có yêu cầu xác minh đang chờ duyệt.",
        });
      }

      // --------------------------------------------------
      // MANUFACTURER
      // --------------------------------------------------

      const manufacturer =
        await Participant.findById(
          manufacturerId
        );

      if (!manufacturer) {
        return res.status(404).json({
          success: false,

          message:
            "Không tìm thấy Manufacturer.",
        });
      }

      const manufacturerType =
        getParticipantType(
          manufacturer
        );

      if (
        manufacturerType !==
        "manufacturer"
      ) {
        return res.status(400).json({
          success: false,

          message:
            "Participant được chọn không phải Manufacturer.",
        });
      }

      if (!manufacturer.walletAddress) {
        return res.status(400).json({
          success: false,

          message:
            "Manufacturer chưa có địa chỉ ví Blockchain.",
        });
      }

      console.log("");
      console.log(
        "======================================"
      );

      console.log(
        "APPROVE BLOCKCHAIN VERIFICATION"
      );

      console.log(
        "======================================"
      );

      console.log(
        "Product:",
        product.productId
      );

      console.log(
        "Product name:",
        product.name
      );

      console.log(
        "Manufacturer:",
        manufacturer.name
      );

      console.log(
        "Wallet:",
        manufacturer.walletAddress
      );

      // --------------------------------------------------
      // ĐẢM BẢO MANUFACTURER TỒN TẠI TRÊN CHAIN
      // --------------------------------------------------

      try {
        await ensureManufacturerOnBlockchain(
          manufacturer
        );
      } catch (manufacturerError) {
        console.error(
          "ENSURE MANUFACTURER ERROR:",
          manufacturerError
        );

        return res.status(500).json({
          success: false,

          message:
            manufacturerError.shortMessage ||
            manufacturerError.reason ||
            manufacturerError.message ||
            "Không thể đăng ký Manufacturer trên Blockchain.",

          blockchainRegistered:
            false,
        });
      }

      // --------------------------------------------------
      // REGISTER PRODUCT
      // --------------------------------------------------

      let blockchainResult;

      try {
        console.log(
          "Đang đăng sản phẩm lên Blockchain..."
        );

        blockchainResult =
          await registerProductOnBlockchain(
            manufacturer.walletAddress,
            product.productId,
            product.name
          );

        console.log(
          "REGISTER PRODUCT RESULT:",
          blockchainResult
        );
      } catch (blockchainError) {
        console.error("");
        console.error(
          "======================================"
        );

        console.error(
          "APPROVE BLOCKCHAIN ERROR"
        );

        console.error(
          "======================================"
        );

        console.error(
          blockchainError
        );

        return res.status(500).json({
          success: false,

          message:
            blockchainError.shortMessage ||
            blockchainError.reason ||
            blockchainError.message ||
            "Không thể đăng ký sản phẩm lên Blockchain.",

          blockchainRegistered:
            false,
        });
      }

      // --------------------------------------------------
      // RESULT
      // --------------------------------------------------

      const blockchainProductId =
        getBlockchainProductId(
          blockchainResult
        );

      const transactionHash =
        getTransactionHash(
          blockchainResult
        );

      if (!blockchainProductId) {
        return res.status(500).json({
          success: false,

          message:
            "Blockchain transaction đã thành công nhưng không lấy được Product ID.",
        });
      }

      if (!transactionHash) {
        return res.status(500).json({
          success: false,

          message:
            "Blockchain transaction đã thành công nhưng không lấy được Transaction Hash.",
        });
      }

      // --------------------------------------------------
      // CHỈ UPDATE MONGODB SAU KHI BLOCKCHAIN THÀNH CÔNG
      // --------------------------------------------------

      product.manufacturer =
        manufacturer._id;

      product.currentOwner =
        manufacturer._id;

      product.blockchainRegistered =
        true;

      product.blockchainProductId =
        blockchainProductId;

      product.transactionHash =
        transactionHash;

      product.verificationStatus =
        "approved";

      product.verificationReviewedAt =
        new Date();

      product.verificationReviewedBy =
        adminId;

      product.verificationNote =
        "Admin đã phê duyệt và đăng ký sản phẩm lên Blockchain.";

      await product.save();

      // --------------------------------------------------
      // RESPONSE
      // --------------------------------------------------

      const updatedProduct =
        await Product.findById(
          product._id
        )
          .populate(
            "manufacturer",
            "name type participantType walletAddress blockchainRegistered"
          )
          .populate(
            "currentOwner",
            "name type participantType walletAddress blockchainRegistered"
          )
          .populate(
            "ownerUser",
            "name email role"
          )
          .populate(
            "verificationReviewedBy",
            "name email role"
          );

      console.log(
        "======================================"
      );

      console.log(
        "BLOCKCHAIN APPROVED SUCCESSFULLY"
      );

      console.log(
        "Blockchain Product ID:",
        blockchainProductId
      );

      console.log(
        "Transaction:",
        transactionHash
      );

      console.log(
        "======================================"
      );

      return res.status(200).json({
        success: true,

        message:
          "Phê duyệt thành công. Sản phẩm đã được đăng ký trên Blockchain.",

        blockchainProductId,

        transactionHash,

        product: updatedProduct,
      });
    } catch (error) {
      console.error(
        "APPROVE VERIFICATION ERROR:",
        error
      );

      return res.status(500).json({
        success: false,

        message:
          error.message ||
          "Không thể phê duyệt xác minh Blockchain.",
      });
    }
  };

// ======================================================
// ADMIN - REJECT VERIFICATION
//
// POST
// /api/products/:productId/reject-verification
// ======================================================

const rejectBlockchainVerification =
  async (req, res) => {
    try {
      const adminId =
        getUserId(req);

      const { productId } =
        req.params;

      const note =
        req.body?.note ||
        req.body?.reason ||
        "";

      if (!adminId) {
        return res.status(401).json({
          success: false,
          message:
            "Bạn chưa đăng nhập.",
        });
      }

      if (
        req.user?.role !== "admin"
      ) {
        return res.status(403).json({
          success: false,

          message:
            "Chỉ Admin mới có quyền từ chối yêu cầu xác minh.",
        });
      }

      const product =
        await Product.findOne({
          productId,
        });

      if (!product) {
        return res.status(404).json({
          success: false,

          message:
            "Không tìm thấy sản phẩm.",
        });
      }

      if (
        product.verificationStatus !==
        "pending"
      ) {
        return res.status(400).json({
          success: false,

          message:
            "Sản phẩm không có yêu cầu đang chờ duyệt.",
        });
      }

      product.verificationStatus =
        "rejected";

      product.verificationReviewedAt =
        new Date();

      product.verificationReviewedBy =
        adminId;

      product.verificationNote =
        note.trim() ||
        "Admin từ chối yêu cầu xác minh.";

      product.blockchainRegistered =
        false;

      product.blockchainProductId =
        null;

      product.transactionHash =
        null;

      await product.save();

      const updatedProduct =
        await Product.findById(
          product._id
        )
          .populate(
            "ownerUser",
            "name email role"
          )
          .populate(
            "verificationReviewedBy",
            "name email role"
          );

      return res.status(200).json({
        success: true,

        message:
          "Đã từ chối yêu cầu xác minh.",

        product: updatedProduct,
      });
    } catch (error) {
      console.error(
        "REJECT VERIFICATION ERROR:",
        error
      );

      return res.status(500).json({
        success: false,

        message:
          error.message ||
          "Không thể từ chối yêu cầu.",
      });
    }
  };

// ======================================================
// TRANSFER PRODUCT
//
// POST /api/products/:productId/transfer
//
// BODY:
// {
//   toParticipantId: "...",
//   note: "..."
// }
// ======================================================

const transferProduct = async (
  req,
  res
) => {
  try {
    const { productId } =
      req.params;

    const {
      toParticipantId,
      note,
    } = req.body;

    // --------------------------------------------------
    // DESTINATION
    // --------------------------------------------------

    if (!toParticipantId) {
      return res.status(400).json({
        success: false,

        message:
          "Vui lòng chọn người nhận.",
      });
    }

    // --------------------------------------------------
    // PRODUCT
    // --------------------------------------------------

    const product =
      await Product.findOne({
        productId,
      })
        .populate("manufacturer")
        .populate("currentOwner");

    if (!product) {
      return res.status(404).json({
        success: false,

        message:
          "Không tìm thấy sản phẩm.",
      });
    }

    // --------------------------------------------------
    // BLOCKCHAIN CHECK
    // --------------------------------------------------

    if (
      !product.blockchainRegistered ||
      !product.blockchainProductId
    ) {
      return res.status(400).json({
        success: false,

        message:
          "Sản phẩm chưa được đăng lên Blockchain.",
      });
    }

    if (!product.currentOwner) {
      return res.status(400).json({
        success: false,

        message:
          "Sản phẩm chưa có chủ sở hữu Blockchain.",
      });
    }

    if (
      !product.currentOwner
        .walletAddress
    ) {
      return res.status(400).json({
        success: false,

        message:
          "Chủ sở hữu hiện tại chưa có địa chỉ ví Blockchain.",
      });
    }

    // --------------------------------------------------
    // RECEIVER
    // --------------------------------------------------

    const toParticipant =
      await Participant.findById(
        toParticipantId
      );

    if (!toParticipant) {
      return res.status(404).json({
        success: false,

        message:
          "Không tìm thấy người nhận.",
      });
    }

    if (!toParticipant.walletAddress) {
      return res.status(400).json({
        success: false,

        message:
          "Người nhận chưa có địa chỉ ví Blockchain.",
      });
    }

    if (
      !toParticipant.blockchainRegistered
    ) {
      return res.status(400).json({
        success: false,

        message:
          "Người nhận chưa được đăng ký Blockchain.",
      });
    }

    if (
      product.currentOwner._id.toString() ===
      toParticipant._id.toString()
    ) {
      return res.status(400).json({
        success: false,

        message:
          "Người nhận đang là chủ sở hữu hiện tại.",
      });
    }

    // --------------------------------------------------
    // BLOCKCHAIN TRANSFER
    //
    // ĐÚNG THỨ TỰ:
    // currentOwnerWallet
    // blockchainProductId
    // receiverWallet
    // --------------------------------------------------

    let blockchainResult;

    try {
      blockchainResult =
        await transferProductOnBlockchain(
          product.currentOwner
            .walletAddress,

          product.blockchainProductId,

          toParticipant.walletAddress
        );
    } catch (blockchainError) {
      console.error(
        "TRANSFER BLOCKCHAIN ERROR:",
        blockchainError
      );

      return res.status(500).json({
        success: false,

        message:
          blockchainError.shortMessage ||
          blockchainError.reason ||
          blockchainError.message ||
          "Không thể chuyển sản phẩm trên Blockchain.",
      });
    }

    const transactionHash =
      getTransactionHash(
        blockchainResult
      );

    if (!transactionHash) {
      return res.status(500).json({
        success: false,

        message:
          "Không lấy được Transaction Hash của giao dịch chuyển sản phẩm.",
      });
    }

    // --------------------------------------------------
    // TRANSFER HISTORY
    // --------------------------------------------------

    await Transfer.create({
      product: product._id,

      fromParticipant:
        product.currentOwner._id,

      toParticipant:
        toParticipant._id,

      note: note || "",

      transactionHash,
    });

    // --------------------------------------------------
    // UPDATE PRODUCT
    // --------------------------------------------------

    product.currentOwner =
      toParticipant._id;

    const destinationType =
      getParticipantType(
        toParticipant
      );

    if (
      destinationType ===
      "distributor"
    ) {
      product.status =
        "distributed";
    }

    if (
      destinationType ===
      "seller"
    ) {
      product.status =
        "for_sale";
    }

    product.transactionHash =
      transactionHash;

    await product.save();

    const updatedProduct =
      await Product.findById(
        product._id
      )
        .populate(
          "manufacturer",
          "name type participantType walletAddress blockchainRegistered"
        )
        .populate(
          "currentOwner",
          "name type participantType walletAddress blockchainRegistered"
        )
        .populate(
          "ownerUser",
          "name email role"
        );

    return res.status(200).json({
      success: true,

      message:
        "Chuyển sản phẩm thành công.",

      transactionHash,

      product: updatedProduct,
    });
  } catch (error) {
    console.error(
      "TRANSFER PRODUCT ERROR:",
      error
    );

    return res.status(500).json({
      success: false,

      message:
        error.message ||
        "Không thể chuyển sản phẩm.",
    });
  }
};

// ======================================================
// EXPORTS
// ======================================================

module.exports = {
  // Product
  getProducts,
  getProduct,
  createProduct,

  // User Product
  createUserProduct,
  getMyProducts,

  // Verification
  requestBlockchainVerification,
  getVerificationRequests,
  approveBlockchainVerification,
  rejectBlockchainVerification,

  // Transfer
  transferProduct,
};