const {
  getContractFunctions,
  getBlockchainInfo,
} = require(
  "../services/blockchainService"
);

const getInfo = async (req, res) => {
  try {
    const info =
      await getBlockchainInfo();

    res.json({
      success: true,
      blockchain: info,
    });
  } catch (error) {
    console.error(error);

    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

const getFunctions = async (req, res) => {
  try {
    const functions =
      await getContractFunctions();

    res.json({
      success: true,
      count: functions.length,
      functions,
    });
  } catch (error) {
    console.error(error);

    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

module.exports = {
  getInfo,
  getFunctions,
};