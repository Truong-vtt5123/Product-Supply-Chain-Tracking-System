require("dotenv").config();

const app = require("./app");
const connectDatabase =
  require("./config/database");

const {
  getBlockchainProvider,
} = require("./config/blockchain");

const PORT = process.env.PORT || 5000;

const startServer = async () => {
  try {
    await connectDatabase();

    const provider =
      getBlockchainProvider();

    const blockNumber =
      await provider.getBlockNumber();

    console.log(
      `Blockchain connected. Current block: ${blockNumber}`
    );

    app.listen(PORT, () => {
      console.log("");
      console.log("==============================");
      console.log("Supply Chain Backend");
      console.log("==============================");
      console.log(
        `Server: http://localhost:${PORT}`
      );
      console.log(
        `Health: http://localhost:${PORT}/api/health`
      );
      console.log("==============================");
    });
  } catch (error) {
    console.error(
      "Server startup failed:",
      error.message
    );

    process.exit(1);
  }
};

startServer();