const express = require("express");

const {
  getInfo,
  getFunctions,
} = require(
  "../controllers/blockchainController"
);

const router = express.Router();

router.get("/info", getInfo);

router.get(
  "/functions",
  getFunctions
);

module.exports = router;