const express = require("express");

const {
  createParticipant,
  getParticipants,
  getParticipantById,
} = require(
  "../controllers/participantController"
);

const protect = require(
  "../middleware/authMiddleware"
);

const authorize = require(
  "../middleware/roleMiddleware"
);

const router = express.Router();

router.use(protect);

router
  .route("/")
  .get(getParticipants)
  .post(
    authorize("admin"),
    createParticipant
  );

router.get(
  "/:id",
  getParticipantById
);

module.exports = router;