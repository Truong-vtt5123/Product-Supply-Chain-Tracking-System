const express = require("express");

// ======================================================
// CONTROLLERS
// ======================================================

const {
  // Product
  createProduct,
  getProducts,
  getProduct,

  // User Product
  createUserProduct,
  getMyProducts,

  // Blockchain Verification
  requestBlockchainVerification,
  getVerificationRequests,
  approveBlockchainVerification,
  rejectBlockchainVerification,

  // Transfer
  transferProduct,
} = require("../controllers/productController");

// ======================================================
// MIDDLEWARE
// ======================================================

const protect = require(
  "../middleware/authMiddleware"
);

const authorize = require(
  "../middleware/roleMiddleware"
);

const upload = require(
  "../middleware/uploadMiddleware"
);

// ======================================================
// ROUTER
// ======================================================

const router = express.Router();

// ======================================================
// 1. USER ĐĂNG SẢN PHẨM
//
// POST /api/products/user
//
// productImage phải trùng với:
// formData.append("productImage", file)
// ======================================================

router.post(
  "/user",
  protect,
  upload.single("productImage"),
  createUserProduct
);

// ======================================================
// 2. USER XEM SẢN PHẨM CỦA MÌNH
//
// GET /api/products/my-products
//
// PHẢI đặt trước /:productId
// ======================================================

router.get(
  "/my-products",
  protect,
  getMyProducts
);

// ======================================================
// 3. ADMIN XEM CÁC YÊU CẦU XÁC MINH BLOCKCHAIN
//
// GET /api/products/admin/verification-requests
//
// PHẢI đặt trước /:productId
// ======================================================

router.get(
  "/admin/verification-requests",
  protect,
  authorize("admin"),
  getVerificationRequests
);

// ======================================================
// 4. USER GỬI YÊU CẦU XÁC MINH BLOCKCHAIN
//
// POST
// /api/products/:productId/request-verification
// ======================================================

router.post(
  "/:productId/request-verification",
  protect,
  requestBlockchainVerification
);

// ======================================================
// 5. ADMIN PHÊ DUYỆT YÊU CẦU
//
// POST
// /api/products/:productId/approve-verification
// ======================================================

router.post(
  "/:productId/approve-verification",
  protect,
  authorize("admin"),
  approveBlockchainVerification
);

// ======================================================
// 6. ADMIN TỪ CHỐI YÊU CẦU
//
// POST
// /api/products/:productId/reject-verification
// ======================================================

router.post(
  "/:productId/reject-verification",
  protect,
  authorize("admin"),
  rejectBlockchainVerification
);

// ======================================================
// 7. LẤY TẤT CẢ SẢN PHẨM
//
// GET /api/products
// ======================================================

router.get(
  "/",
  protect,
  getProducts
);

// ======================================================
// 8. ADMIN / MANUFACTURER TẠO SẢN PHẨM
//
// POST /api/products
//
// Đây là luồng sản phẩm được tạo trực tiếp
// bởi Admin hoặc Manufacturer.
// ======================================================

router.post(
  "/",
  protect,
  authorize(
    "admin",
    "manufacturer"
  ),
  createProduct
);

// ======================================================
// 9. TRANSFER PRODUCT
//
// POST /api/products/:productId/transfer
//
// Manufacturer -> Distributor -> Seller
// ======================================================

router.post(
  "/:productId/transfer",
  protect,
  authorize(
    "admin",
    "manufacturer",
    "distributor"
  ),
  transferProduct
);

// ======================================================
// 10. LẤY CHI TIẾT MỘT SẢN PHẨM
//
// GET /api/products/:productId
//
// QUAN TRỌNG:
// Route động này để gần cuối file.
// ======================================================

router.get(
  "/:productId",
  protect,
  getProduct
);

// ======================================================
// EXPORT
// ======================================================

module.exports = router;