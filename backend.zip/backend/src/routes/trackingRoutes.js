const express = require("express");

const router = express.Router();

const {
  trackProduct,
} = require("../controllers/trackingController");

router.get(
  "/:productId",
  trackProduct
);

module.exports = router;