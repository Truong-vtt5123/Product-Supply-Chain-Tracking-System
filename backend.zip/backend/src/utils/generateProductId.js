const generateProductId = () => {
  const timestamp = Date.now();

  const random = Math.floor(
    100000 + Math.random() * 900000
  );

  return `PRD-${timestamp}-${random}`;
};

module.exports = generateProductId;