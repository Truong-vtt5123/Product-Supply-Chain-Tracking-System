const mongoose = require("mongoose");

const productSchema = new mongoose.Schema(
  {
    // ==================================================
    // THÔNG TIN SẢN PHẨM
    // ==================================================

    productId: {
      type: String,
      required: true,
      unique: true,
      trim: true,
    },

    blockchainProductId: {
      type: String,
      default: null,
    },

    name: {
      type: String,
      required: true,
      trim: true,
    },

    manufacturerName: {
      type: String,
      default: "",
      trim: true,
    },

    description: {
      type: String,
      default: "",
      trim: true,
    },

    productImage: {
      type: String,
      default: null,
    },

    // ==================================================
    // PARTICIPANT / USER
    // ==================================================

    manufacturer: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Participant",
      default: null,
    },

    currentOwner: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Participant",
      default: null,
    },

    ownerUser: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },

    // ==================================================
    // BLOCKCHAIN
    // ==================================================

    blockchainRegistered: {
      type: Boolean,
      default: false,
    },

    transactionHash: {
      type: String,
      default: null,
    },

    // ==================================================
    // TRẠNG THÁI XÁC MINH BLOCKCHAIN
    // ==================================================

    verificationStatus: {
      type: String,

      enum: [
        "not_requested",
        "pending",
        "approved",
        "rejected",
      ],

      default: "not_requested",
    },

    // User gửi yêu cầu lúc nào
    verificationRequestedAt: {
      type: Date,
      default: null,
    },

    // Admin xử lý lúc nào
    verificationReviewedAt: {
      type: Date,
      default: null,
    },

    // Admin nào xử lý
    verificationReviewedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },

    // Ghi chú / lý do từ chối của Admin
    verificationNote: {
      type: String,
      default: "",
      trim: true,
    },

    // ==================================================
    // TRẠNG THÁI CHUỖI CUNG ỨNG
    // ==================================================

    status: {
      type: String,

      enum: [
        "manufactured",
        "in_transit",
        "distributed",
        "for_sale",
        "sold",
      ],

      default: "manufactured",
    },

    // ==================================================
    // DỮ LIỆU BỔ SUNG
    // category, origin...
    // ==================================================

    metadata: {
      type: Object,
      default: {},
    },
  },
  {
    timestamps: true,
  }
);

// ======================================================
// INDEX
// ======================================================

// User xem sản phẩm của chính mình
productSchema.index({
  ownerUser: 1,
  createdAt: -1,
});

// Admin lấy nhanh yêu cầu đang chờ
productSchema.index({
  verificationStatus: 1,
  verificationRequestedAt: -1,
});

// Truy vấn theo trạng thái chuỗi cung ứng
productSchema.index({
  status: 1,
});

// ======================================================
// EXPORT
// ======================================================

module.exports = mongoose.model(
  "Product",
  productSchema
);