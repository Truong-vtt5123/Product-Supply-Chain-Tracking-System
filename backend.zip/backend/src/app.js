const express = require("express");
const cors = require("cors");
const path = require("path");

const authRoutes = require(
  "./routes/authRoutes"
);
const participantRoutes = require(
  "./routes/participantRoutes"
);
const blockchainRoutes = require(
  "./routes/blockchainRoutes"
);
const productRoutes = require(
  "./routes/productRoutes"
);

const trackingRoutes = require(
  "./routes/trackingRoutes"
);

const app = express();

app.use(cors());

app.use(express.json());

app.use(
  express.urlencoded({
    extended: true,
  })
);
app.use(
  "/uploads",
  express.static(
    path.join(__dirname, "../uploads")
  )
);

// ===============================
// ROUTES
// ===============================

app.use(
  "/api/auth",
  authRoutes
);
app.use(
  "/api/participants",
  participantRoutes
);
app.use(
  "/api/blockchain",
  blockchainRoutes
);
app.use(
  "/api/products",
  productRoutes
);

app.use(
  "/api/tracking",
  trackingRoutes
);

app.get("/", (req, res) => {
  res.json({
    success: true,
    message:
      "Product Supply Chain API is running",
  });
});

app.get(
  "/api/health",
  (req, res) => {
    res.status(200).json({
      success: true,
      service:
        "Product Supply Chain API",
      status: "OK",
      timestamp:
        new Date().toISOString(),
    });
  }
);

// 404
app.use((req, res) => {
  res.status(404).json({
    success: false,
    message: "Route not found",
  });
});

module.exports = app;