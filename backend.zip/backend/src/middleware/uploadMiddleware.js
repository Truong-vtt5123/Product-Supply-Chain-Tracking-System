const multer = require("multer");
const path = require("path");
const fs = require("fs");

// ======================================================
// THƯ MỤC LƯU ẢNH
// backend/uploads/products
// ======================================================

const uploadDirectory = path.join(
  __dirname,
  "../../uploads/products"
);

// Tự tạo thư mục nếu chưa tồn tại
if (!fs.existsSync(uploadDirectory)) {
  fs.mkdirSync(uploadDirectory, {
    recursive: true,
  });
}

// ======================================================
// STORAGE
// ======================================================

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadDirectory);
  },

  filename: (req, file, cb) => {
    const extension = path
      .extname(file.originalname)
      .toLowerCase();

    const fileName =
      `product-${Date.now()}-${Math.round(
        Math.random() * 1e9
      )}${extension}`;

    cb(null, fileName);
  },
});

// ======================================================
// KIỂM TRA LOẠI FILE
// ======================================================

const fileFilter = (req, file, cb) => {
  const allowedTypes = [
    "image/jpeg",
    "image/png",
    "image/webp",
  ];

  if (allowedTypes.includes(file.mimetype)) {
    return cb(null, true);
  }

  return cb(
    new Error(
      "Chỉ cho phép ảnh JPG, JPEG, PNG hoặc WEBP."
    ),
    false
  );
};

// ======================================================
// TẠO MULTER INSTANCE
// ======================================================

const upload = multer({
  storage,

  limits: {
    fileSize: 5 * 1024 * 1024,
  },

  fileFilter,
});

// ======================================================
// CHỈ EXPORT UPLOAD
// KHÔNG GỌI upload.single() TRONG FILE NÀY
// ======================================================

module.exports = upload;