const { ethers } = require("ethers");

const getBlockchainProvider = () => {
  if (!process.env.BLOCKCHAIN_RPC_URL) {
    throw new Error(
      "BLOCKCHAIN_RPC_URL is missing"
    );
  }

  return new ethers.JsonRpcProvider(
    process.env.BLOCKCHAIN_RPC_URL
  );
};

const getContractAddress = () => {
  if (!process.env.CONTRACT_ADDRESS) {
    throw new Error(
      "CONTRACT_ADDRESS is missing"
    );
  }

  return process.env.CONTRACT_ADDRESS;
};

module.exports = {
  getBlockchainProvider,
  getContractAddress,
};