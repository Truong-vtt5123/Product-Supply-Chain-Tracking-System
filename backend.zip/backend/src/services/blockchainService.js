const { ethers } = require("ethers");
const fs = require("fs");
const path = require("path");

// ======================================================
// BIẾN BLOCKCHAIN
// ======================================================

let provider = null;
let adminSigner = null;
let contract = null;

// ======================================================
// ĐƯỜNG DẪN ARTIFACT
// ======================================================

const getArtifact = () => {
  const artifactPath = path.resolve(
    __dirname,
    "../../../blockchain/artifacts/contracts/SupplyChain.sol/SupplyChain.json"
  );

  if (!fs.existsSync(artifactPath)) {
    throw new Error(
      "Không tìm thấy SupplyChain.json. " +
        "Hãy chạy: npx hardhat compile"
    );
  }

  try {
    const artifact = JSON.parse(
      fs.readFileSync(artifactPath, "utf8")
    );

    if (!artifact.abi) {
      throw new Error(
        "Artifact không có ABI."
      );
    }

    return artifact;
  } catch (error) {
    console.error(
      "❌ Lỗi đọc SupplyChain artifact:",
      error
    );

    throw error;
  }
};

// ======================================================
// KIỂM TRA ENV
// ======================================================

const validateEnvironment = () => {
  const rpcUrl =
    process.env.BLOCKCHAIN_RPC_URL;

  const contractAddress =
    process.env.CONTRACT_ADDRESS;

  if (!rpcUrl) {
    throw new Error(
      "BLOCKCHAIN_RPC_URL chưa được cấu hình trong backend/.env"
    );
  }

  if (!contractAddress) {
    throw new Error(
      "CONTRACT_ADDRESS chưa được cấu hình trong backend/.env"
    );
  }

  if (
    !ethers.isAddress(contractAddress)
  ) {
    throw new Error(
      `CONTRACT_ADDRESS không hợp lệ: ${contractAddress}`
    );
  }

  return {
    rpcUrl,
    contractAddress,
  };
};

// ======================================================
// KHỞI TẠO BLOCKCHAIN
// ======================================================

const initializeBlockchain = async () => {
  if (
    provider &&
    adminSigner &&
    contract
  ) {
    return contract;
  }

  try {
    const {
      rpcUrl,
      contractAddress,
    } = validateEnvironment();

    console.log("");
    console.log(
      "========================================"
    );
    console.log(
      "🔗 INITIALIZING BLOCKCHAIN"
    );
    console.log(
      "========================================"
    );

    console.log(
      "RPC:",
      rpcUrl
    );

    console.log(
      "Contract:",
      contractAddress
    );

    // ----------------------------------------------
    // Provider
    // ----------------------------------------------

    provider =
      new ethers.JsonRpcProvider(
        rpcUrl
      );

    // Kiểm tra Hardhat node
    const network =
      await provider.getNetwork();

    console.log(
      "Chain ID:",
      network.chainId.toString()
    );

    // ----------------------------------------------
    // Kiểm tra contract có tồn tại không
    // ----------------------------------------------

    const code =
      await provider.getCode(
        contractAddress
      );

    if (
      !code ||
      code === "0x"
    ) {
      provider = null;
      adminSigner = null;
      contract = null;

      throw new Error(
        `Không tìm thấy Smart Contract tại ${contractAddress}. ` +
          "Có thể Hardhat đã restart và CONTRACT_ADDRESS hiện tại đã cũ. " +
          "Hãy deploy lại SupplyChain.sol rồi cập nhật backend/.env."
      );
    }

    console.log(
      "✅ Contract bytecode found"
    );

    // ----------------------------------------------
    // Admin signer = Hardhat account #0
    // ----------------------------------------------

    adminSigner =
      await provider.getSigner(0);

    const adminAddress =
      await adminSigner.getAddress();

    console.log(
      "Admin wallet:",
      adminAddress
    );

    // ----------------------------------------------
    // Load ABI
    // ----------------------------------------------

    const artifact =
      getArtifact();

    // ----------------------------------------------
    // Contract
    // ----------------------------------------------

    contract =
      new ethers.Contract(
        contractAddress,
        artifact.abi,
        adminSigner
      );

    console.log(
      "✅ Blockchain initialized"
    );

    console.log(
      "========================================"
    );
    console.log("");

    return contract;
  } catch (error) {
    provider = null;
    adminSigner = null;
    contract = null;

    console.error(
      "❌ BLOCKCHAIN INITIALIZATION ERROR:"
    );

    console.error(
      error.message
    );

    throw error;
  }
};

// ======================================================
// RESET BLOCKCHAIN CONNECTION
// ======================================================

const resetBlockchainConnection = () => {
  provider = null;
  adminSigner = null;
  contract = null;

  console.log(
    "🔄 Blockchain connection reset"
  );
};

// ======================================================
// BLOCKCHAIN INFORMATION
// ======================================================

const getBlockchainInfo = async () => {
  const supplyChain =
    await initializeBlockchain();

  const network =
    await provider.getNetwork();

  const contractAddress =
    await supplyChain.getAddress();

  const signerAddress =
    await adminSigner.getAddress();

  const blockNumber =
    await provider.getBlockNumber();

  return {
    contractAddress,

    signerAddress,

    chainId:
      network.chainId.toString(),

    blockNumber,
  };
};

// ======================================================
// DANH SÁCH FUNCTION CỦA CONTRACT
// ======================================================

const getContractFunctions = async () => {
  const supplyChain =
    await initializeBlockchain();

  return supplyChain.interface.fragments
    .filter(
      (fragment) =>
        fragment.type ===
        "function"
    )
    .map(
      (fragment) =>
        fragment.format()
    );
};

// ======================================================
// ROLE MAP
//
// Solidity:
// None = 0
// Manufacturer = 1
// Distributor = 2
// Seller = 3
// ======================================================

const roleMap = {
  manufacturer: 1,
  distributor: 2,
  seller: 3,
};

// ======================================================
// REGISTER PARTICIPANT
// ======================================================

const registerParticipantOnBlockchain =
  async (
    walletAddress,
    name,
    participantType
  ) => {
    try {
      const supplyChain =
        await initializeBlockchain();

      if (
        !ethers.isAddress(
          walletAddress
        )
      ) {
        throw new Error(
          "Địa chỉ ví Participant không hợp lệ."
        );
      }

      const normalizedType =
        String(
          participantType
        )
          .trim()
          .toLowerCase();

      const role =
        roleMap[
          normalizedType
        ];

      if (!role) {
        throw new Error(
          `Participant type không hợp lệ: ${participantType}`
        );
      }

      console.log("");
      console.log(
        "========================================"
      );

      console.log(
        "REGISTER PARTICIPANT"
      );

      console.log(
        "Wallet:",
        walletAddress
      );

      console.log(
        "Name:",
        name
      );

      console.log(
        "Role:",
        normalizedType
      );

      console.log(
        "========================================"
      );

      const tx =
        await supplyChain
          .registerParticipant(
            walletAddress,
            name,
            role
          );

      console.log(
        "TX:",
        tx.hash
      );

      const receipt =
        await tx.wait();

      console.log(
        "✅ Participant registered"
      );

      console.log(
        "Block:",
        receipt.blockNumber
      );

      return {
        transactionHash:
          tx.hash,

        blockNumber:
          receipt.blockNumber,
      };
    } catch (error) {
      console.error(
        "❌ REGISTER PARTICIPANT ERROR:"
      );

      console.error(
        error
      );

      throw error;
    }
  };

// ======================================================
// GET PARTICIPANT
// ======================================================

const getParticipantFromBlockchain =
  async (walletAddress) => {
    try {
      const supplyChain =
        await initializeBlockchain();

      if (
        !ethers.isAddress(
          walletAddress
        )
      ) {
        throw new Error(
          "Địa chỉ ví Participant không hợp lệ."
        );
      }

      return await supplyChain
        .getParticipant(
          walletAddress
        );
    } catch (error) {
      console.error(
        "❌ GET PARTICIPANT ERROR:",
        error
      );

      throw error;
    }
  };

// ======================================================
// REGISTER PRODUCT ON BLOCKCHAIN
// ======================================================

const registerProductOnBlockchain =
  async (
    manufacturerWallet,
    productCode,
    productName
  ) => {
    try {
      await initializeBlockchain();

      // ----------------------------------------------
      // Validate
      // ----------------------------------------------

      if (
        !manufacturerWallet
      ) {
        throw new Error(
          "Thiếu manufacturerWallet."
        );
      }

      if (
        !ethers.isAddress(
          manufacturerWallet
        )
      ) {
        throw new Error(
          `Manufacturer wallet không hợp lệ: ${manufacturerWallet}`
        );
      }

      if (
        !productCode ||
        !String(
          productCode
        ).trim()
      ) {
        throw new Error(
          "Thiếu productCode."
        );
      }

      if (
        !productName ||
        !String(
          productName
        ).trim()
      ) {
        throw new Error(
          "Thiếu productName."
        );
      }

      // ----------------------------------------------
      // Manufacturer signer
      //
      // registerProduct() sử dụng msg.sender
      // nên bắt buộc phải ký bằng Manufacturer.
      // ----------------------------------------------

      const manufacturerSigner =
        await provider.getSigner(
          manufacturerWallet
        );

      const signerAddress =
        await manufacturerSigner
          .getAddress();

      console.log("");
      console.log(
        "========================================"
      );

      console.log(
        "REGISTER PRODUCT ON BLOCKCHAIN"
      );

      console.log(
        "Manufacturer:",
        signerAddress
      );

      console.log(
        "Product code:",
        productCode
      );

      console.log(
        "Product name:",
        productName
      );

      console.log(
        "Contract:",
        process.env
          .CONTRACT_ADDRESS
      );

      console.log(
        "========================================"
      );

      // ----------------------------------------------
      // Contract với Manufacturer signer
      // ----------------------------------------------

      const artifact =
        getArtifact();

      const manufacturerContract =
        new ethers.Contract(
          process.env
            .CONTRACT_ADDRESS,
          artifact.abi,
          manufacturerSigner
        );

      // ----------------------------------------------
      // Kiểm tra Participant
      // ----------------------------------------------

      try {
        const participant =
          await manufacturerContract
            .getParticipant(
              signerAddress
            );

        console.log(
          "Manufacturer participant:",
          participant
        );
      } catch (error) {
        console.warn(
          "⚠ Không đọc được participant:",
          error.message
        );
      }

      // ----------------------------------------------
      // Đếm product trước transaction
      // ----------------------------------------------

      let totalBefore = null;

      try {
        totalBefore =
          await manufacturerContract
            .getTotalProducts();

        console.log(
          "Total products before:",
          totalBefore.toString()
        );
      } catch (error) {
        console.warn(
          "⚠ Không đọc được getTotalProducts trước TX:",
          error.message
        );
      }

      // ----------------------------------------------
      // REGISTER PRODUCT
      // ----------------------------------------------

      const tx =
        await manufacturerContract
          .registerProduct(
            String(
              productCode
            ).trim(),

            String(
              productName
            ).trim()
          );

      console.log(
        "⏳ TX sent:",
        tx.hash
      );

      const receipt =
        await tx.wait();

      if (
        receipt.status !== 1
      ) {
        throw new Error(
          "Blockchain transaction thất bại."
        );
      }

      console.log(
        "✅ TX confirmed"
      );

      console.log(
        "Block:",
        receipt.blockNumber
      );

      // ----------------------------------------------
      // Lấy Blockchain Product ID
      //
      // KHÔNG gọi getProductByCode ở đây.
      //
      // Lỗi trước:
      // could not decode result data
      // value="0x"
      // method="getProductByCode"
      //
      // Thay bằng getTotalProducts().
      // ----------------------------------------------

      let blockchainProductId =
        null;

      try {
        const totalAfter =
          await manufacturerContract
            .getTotalProducts();

        console.log(
          "Total products after:",
          totalAfter.toString()
        );

        /*
         * Contract của bạn dùng ID sản phẩm
         * tăng dần.
         *
         * Nếu totalProducts chính là ID cuối
         * thì dùng trực tiếp.
         */

        blockchainProductId =
          totalAfter.toString();

        console.log(
          "Blockchain Product ID:",
          blockchainProductId
        );
      } catch (error) {
        console.warn(
          "⚠ Không lấy được getTotalProducts:",
          error.message
        );

        /*
         * Transaction vẫn đã thành công.
         * Không được coi toàn bộ việc đăng ký
         * là thất bại chỉ vì không đọc được ID.
         */

        blockchainProductId =
          null;
      }

      return {
        blockchainProductId,

        transactionHash:
          tx.hash,

        blockNumber:
          receipt.blockNumber,

        success: true,
      };
    } catch (error) {
      console.error("");
      console.error(
        "========================================"
      );

      console.error(
        "❌ REGISTER PRODUCT BLOCKCHAIN ERROR"
      );

      console.error(
        "========================================"
      );

      console.error(
        "Message:",
        error.message
      );

      if (
        error.shortMessage
      ) {
        console.error(
          "Short message:",
          error.shortMessage
        );
      }

      if (error.reason) {
        console.error(
          "Reason:",
          error.reason
        );
      }

      if (error.code) {
        console.error(
          "Code:",
          error.code
        );
      }

      console.error(
        "========================================"
      );
      console.error("");

      throw error;
    }
  };

// ======================================================
// TRANSFER PRODUCT
// ======================================================

const transferProductOnBlockchain =
  async (
    currentOwnerWallet,
    blockchainProductId,
    receiverWallet
  ) => {
    try {
      await initializeBlockchain();

      if (
        !ethers.isAddress(
          currentOwnerWallet
        )
      ) {
        throw new Error(
          "Ví current owner không hợp lệ."
        );
      }

      if (
        !ethers.isAddress(
          receiverWallet
        )
      ) {
        throw new Error(
          "Ví receiver không hợp lệ."
        );
      }

      if (
        blockchainProductId ===
          null ||
        blockchainProductId ===
          undefined
      ) {
        throw new Error(
          "Thiếu blockchainProductId."
        );
      }

      const ownerSigner =
        await provider.getSigner(
          currentOwnerWallet
        );

      const artifact =
        getArtifact();

      const ownerContract =
        new ethers.Contract(
          process.env
            .CONTRACT_ADDRESS,
          artifact.abi,
          ownerSigner
        );

      console.log("");
      console.log(
        "========================================"
      );

      console.log(
        "TRANSFER PRODUCT"
      );

      console.log(
        "Product ID:",
        blockchainProductId
      );

      console.log(
        "From:",
        currentOwnerWallet
      );

      console.log(
        "To:",
        receiverWallet
      );

      console.log(
        "========================================"
      );

      const tx =
        await ownerContract
          .transferProduct(
            blockchainProductId,
            receiverWallet
          );

      console.log(
        "TX:",
        tx.hash
      );

      const receipt =
        await tx.wait();

      if (
        receipt.status !== 1
      ) {
        throw new Error(
          "Transfer transaction thất bại."
        );
      }

      console.log(
        "✅ Product transferred"
      );

      return {
        transactionHash:
          tx.hash,

        blockNumber:
          receipt.blockNumber,
      };
    } catch (error) {
      console.error(
        "❌ TRANSFER PRODUCT ERROR:"
      );

      console.error(
        error
      );

      throw error;
    }
  };

// ======================================================
// GET BLOCKCHAIN PRODUCT
// ======================================================

const getBlockchainProduct =
  async (
    blockchainProductId
  ) => {
    try {
      const supplyChain =
        await initializeBlockchain();

      if (
        blockchainProductId ===
          null ||
        blockchainProductId ===
          undefined
      ) {
        throw new Error(
          "Thiếu blockchainProductId."
        );
      }

      return await supplyChain
        .getProduct(
          blockchainProductId
        );
    } catch (error) {
      console.error(
        "❌ GET BLOCKCHAIN PRODUCT ERROR:"
      );

      console.error(
        error
      );

      throw error;
    }
  };

// ======================================================
// GET PRODUCT BY CODE
//
// Hàm này vẫn giữ để dùng khi cần tracking.
// Nhưng KHÔNG dùng nó ngay sau registerProduct.
// ======================================================

const getBlockchainProductByCode =
  async (productCode) => {
    try {
      const supplyChain =
        await initializeBlockchain();

      if (
        !productCode ||
        !String(
          productCode
        ).trim()
      ) {
        throw new Error(
          "Thiếu productCode."
        );
      }

      const product =
        await supplyChain
          .getProductByCode(
            String(
              productCode
            ).trim()
          );

      return product;
    } catch (error) {
      console.error(
        "❌ GET PRODUCT BY CODE ERROR:"
      );

      console.error(
        error
      );

      throw error;
    }
  };

// ======================================================
// GET BLOCKCHAIN PRODUCT HISTORY
// ======================================================

const getBlockchainProductHistory =
  async (
    blockchainProductId
  ) => {
    try {
      const supplyChain =
        await initializeBlockchain();

      if (
        blockchainProductId ===
          null ||
        blockchainProductId ===
          undefined
      ) {
        throw new Error(
          "Thiếu blockchainProductId."
        );
      }

      return await supplyChain
        .getProductHistory(
          blockchainProductId
        );
    } catch (error) {
      console.error(
        "❌ GET PRODUCT HISTORY ERROR:"
      );

      console.error(
        error
      );

      throw error;
    }
  };

// ======================================================
// GET TOTAL PRODUCTS
// ======================================================

const getTotalBlockchainProducts =
  async () => {
    try {
      const supplyChain =
        await initializeBlockchain();

      const total =
        await supplyChain
          .getTotalProducts();

      return total.toString();
    } catch (error) {
      console.error(
        "❌ GET TOTAL PRODUCTS ERROR:",
        error
      );

      throw error;
    }
  };

// ======================================================
// GET ALL PRODUCT IDS
// ======================================================

const getAllBlockchainProductIds =
  async () => {
    try {
      const supplyChain =
        await initializeBlockchain();

      const ids =
        await supplyChain
          .getAllProductIds();

      return ids.map(
        (id) =>
          id.toString()
      );
    } catch (error) {
      console.error(
        "❌ GET ALL PRODUCT IDS ERROR:",
        error
      );

      throw error;
    }
  };

// ======================================================
// GET TOTAL PARTICIPANTS
// ======================================================

const getTotalBlockchainParticipants =
  async () => {
    try {
      const supplyChain =
        await initializeBlockchain();

      const total =
        await supplyChain
          .getTotalParticipants();

      return total.toString();
    } catch (error) {
      console.error(
        "❌ GET TOTAL PARTICIPANTS ERROR:",
        error
      );

      throw error;
    }
  };

// ======================================================
// GET ALL PARTICIPANT ADDRESSES
// ======================================================

const getAllParticipantAddresses =
  async () => {
    try {
      const supplyChain =
        await initializeBlockchain();

      return await supplyChain
        .getAllParticipantAddresses();
    } catch (error) {
      console.error(
        "❌ GET PARTICIPANT ADDRESSES ERROR:",
        error
      );

      throw error;
    }
  };

// ======================================================
// EXPORT
// ======================================================

module.exports = {
  // Connection
  initializeBlockchain,
  resetBlockchainConnection,

  // Information
  getBlockchainInfo,
  getContractFunctions,

  // Participants
  registerParticipantOnBlockchain,
  getParticipantFromBlockchain,
  getTotalBlockchainParticipants,
  getAllParticipantAddresses,

  // Products
  registerProductOnBlockchain,
  getBlockchainProduct,
  getBlockchainProductByCode,
  getTotalBlockchainProducts,
  getAllBlockchainProductIds,

  // Transfer
  transferProductOnBlockchain,

  // Tracking
  getBlockchainProductHistory,
};