// productService.js
