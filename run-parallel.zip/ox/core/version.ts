/** @internal */
export const version = '0.1.1'
