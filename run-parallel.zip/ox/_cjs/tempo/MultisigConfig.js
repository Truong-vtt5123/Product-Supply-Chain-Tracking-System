"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.InvalidConfigError = exports.zeroSalt = exports.signatureTypeByte = exports.maxVersion = exports.maxThreshold = exports.maxSignatures = exports.maxOwners = exports.maxOwnerSignatureBytes = void 0;
exports.assert = assert;
exports.from = from;
exports.fromRpc = fromRpc;
exports.fromTuple = fromTuple;
exports.getAddress = getAddress;
exports.getCommitment = getCommitment;
exports.getSignPayload = getSignPayload;
exports.toRpc = toRpc;
exports.toTuple = toTuple;
exports.validate = validate;
const Address = require("../core/Address.js");
const ContractAddress = require("../core/ContractAddress.js");
const Errors = require("../core/Errors.js");
const Hash = require("../core/Hash.js");
const Hex = require("../core/Hex.js");
exports.maxOwnerSignatureBytes = 2049;
exports.maxOwners = 48;
exports.maxSignatures = 8;
exports.maxThreshold = 8;
exports.maxVersion = 2n ** 64n - 1n;
exports.signatureTypeByte = '0x05';
exports.zeroSalt = `0x${'00'.repeat(32)}`;
const accountDomain = 'tempo:multisig:account';
const configDomain = 'tempo:multisig:config';
const recoveryWalletInitCodeHash = '0x583cc63a2e37f645b43eac911b1a6d6de08b83abdc308c61364edda8cfc3bd37';
const signatureDomain = 'tempo:multisig:signature';
function assert(config) {
    const { owners, salt, threshold, version = 0n } = config;
    if (typeof salt !== 'undefined' && Hex.size(salt) !== 32)
        throw new InvalidConfigError({ reason: 'salt must be 32 bytes' });
    assertVersion(version);
    if (owners.length === 0)
        throw new InvalidConfigError({ reason: 'owners cannot be empty' });
    if (owners.length > exports.maxOwners)
        throw new InvalidConfigError({ reason: 'too many owners' });
    if (!Number.isInteger(Number(threshold)))
        throw new InvalidConfigError({ reason: 'threshold must be an integer' });
    if (Number(threshold) < 1)
        throw new InvalidConfigError({ reason: 'threshold cannot be zero' });
    if (Number(threshold) > exports.maxThreshold)
        throw new InvalidConfigError({ reason: 'threshold exceeds max threshold' });
    let totalWeight = 0;
    const weights = [];
    let previous;
    for (const owner of owners) {
        if (!Address.validate(owner.owner) || Hex.toBigInt(owner.owner) === 0n)
            throw new InvalidConfigError({ reason: 'owner cannot be zero' });
        if (!Number.isInteger(Number(owner.weight)))
            throw new InvalidConfigError({
                reason: 'owner weight must be an integer',
            });
        if (Number(owner.weight) < 1)
            throw new InvalidConfigError({ reason: 'owner weight cannot be zero' });
        const current = Hex.toBigInt(owner.owner);
        if (typeof previous !== 'undefined' && previous >= current)
            throw new InvalidConfigError({
                reason: 'owners must be strictly ascending',
            });
        previous = current;
        const weight = Number(owner.weight);
        totalWeight += weight;
        weights.push(weight);
    }
    if (totalWeight > 0xff)
        throw new InvalidConfigError({
            reason: 'total owner weight exceeds u8 max',
        });
    if (Number(threshold) > totalWeight)
        throw new InvalidConfigError({
            reason: 'threshold exceeds total owner weight',
        });
    const reachableWeight = weights
        .sort((a, b) => b - a)
        .slice(0, exports.maxSignatures)
        .reduce((sum, weight) => sum + weight, 0);
    if (Number(threshold) > reachableWeight)
        throw new InvalidConfigError({
            reason: `threshold exceeds weight reachable by ${exports.maxSignatures} owner signatures`,
        });
}
function from(config) {
    const version = config.version ?? 0n;
    assertVersion(version);
    const owners = [...config.owners].sort((a, b) => Hex.toBigInt(a.owner) < Hex.toBigInt(b.owner) ? -1 : 1);
    const normalized = {
        owners,
        salt: config.salt ? Hex.padLeft(config.salt, 32) : exports.zeroSalt,
        threshold: config.threshold,
        version: BigInt(version),
    };
    assert(normalized);
    return normalized;
}
function fromRpc(config) {
    return from({
        ...config,
        version: Hex.toBigInt(config.version),
    });
}
function fromTuple(tuple) {
    const [salt, version, threshold, owners] = tuple;
    if (tuple.length !== 4 ||
        typeof salt !== 'string' ||
        Hex.size(salt) !== 32 ||
        typeof version !== 'string' ||
        Hex.size(version) > 8 ||
        version.startsWith('0x00') ||
        typeof threshold !== 'string' ||
        Hex.size(threshold) > 1 ||
        threshold.startsWith('0x00') ||
        !Array.isArray(owners) ||
        owners.some((owner) => !Array.isArray(owner) ||
            owner.length !== 2 ||
            typeof owner[0] !== 'string' ||
            !Address.validate(owner[0]) ||
            typeof owner[1] !== 'string' ||
            Hex.size(owner[1]) > 1 ||
            owner[1].startsWith('0x00')))
        throw new InvalidConfigError({ reason: 'invalid config RLP tuple' });
    const config = {
        salt: salt && salt !== '0x' ? Hex.padLeft(salt, 32) : exports.zeroSalt,
        version: version === '0x' ? 0n : Hex.toBigInt(version),
        threshold: threshold === '0x' ? 0 : Hex.toNumber(threshold),
        owners: owners.map((owner) => {
            const [ownerAddress, weight] = owner;
            return {
                owner: ownerAddress,
                weight: !weight || weight === '0x' ? 0 : Hex.toNumber(weight),
            };
        }),
    };
    assert(config);
    return config;
}
function getAddress(config, options) {
    Address.assert(options.factory);
    assert(config);
    if (BigInt(config.version ?? 0) !== 0n)
        throw new InvalidConfigError({
            reason: 'account address requires version zero',
        });
    const accountSalt = Hash.keccak256(Hex.concat(Hex.fromString(accountDomain), Hex.padLeft(config.salt ?? exports.zeroSalt, 32), Hex.fromNumber(config.threshold, { size: 1 }), Hex.fromNumber(config.owners.length, { size: 1 }), ...config.owners.flatMap((owner) => [
        owner.owner,
        Hex.fromNumber(owner.weight, { size: 1 }),
    ])));
    const account = ContractAddress.fromCreate2({
        bytecodeHash: recoveryWalletInitCodeHash,
        from: options.factory,
        salt: accountSalt,
    });
    if (Hex.toBigInt(account) === 0n)
        throw new InvalidConfigError({ reason: 'derived account cannot be zero' });
    if (config.owners.some((owner) => Address.isEqual(owner.owner, account)))
        throw new InvalidConfigError({
            reason: 'derived account cannot be an owner',
        });
    return account;
}
function getCommitment(config) {
    assert(config);
    return Hash.keccak256(Hex.concat(Hex.fromString(configDomain), Hex.padLeft(config.salt ?? exports.zeroSalt, 32), Hex.fromNumber(config.version ?? 0n, { size: 8 }), Hex.fromNumber(config.threshold, { size: 1 }), Hex.fromNumber(config.owners.length, { size: 1 }), ...config.owners.flatMap((owner) => [
        owner.owner,
        Hex.fromNumber(owner.weight, { size: 1 }),
    ])));
}
function getSignPayload(value) {
    const { account, config, payload } = value;
    assertVersion(config.version);
    Address.assert(account);
    if (Hex.size(Hex.from(payload)) !== 32)
        throw new InvalidConfigError({ reason: 'payload must be 32 bytes' });
    return Hash.keccak256(Hex.concat(Hex.fromString(signatureDomain), Hex.from(payload), account, Hex.fromNumber(config.version ?? 0n, { size: 8 })));
}
function toRpc(config) {
    const value = from(config);
    return {
        owners: value.owners.map((owner) => ({
            owner: owner.owner,
            weight: Number(owner.weight),
        })),
        salt: value.salt,
        threshold: Number(value.threshold),
        version: Hex.fromNumber(value.version),
    };
}
function toTuple(config) {
    assert(config);
    const owners = config.owners.map((owner) => [owner.owner, Hex.fromNumber(owner.weight)]);
    const salt = config.salt ? Hex.padLeft(config.salt, 32) : exports.zeroSalt;
    const version = BigInt(config.version ?? 0);
    return [
        salt,
        version === 0n ? '0x' : Hex.fromNumber(version),
        Hex.fromNumber(config.threshold),
        owners,
    ];
}
function validate(config) {
    try {
        assert(config);
        return true;
    }
    catch {
        return false;
    }
}
class InvalidConfigError extends Errors.BaseError {
    constructor({ reason }) {
        super(`Invalid native multisig config: ${reason}.`);
        Object.defineProperty(this, "name", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 'MultisigConfig.InvalidConfigError'
        });
    }
}
exports.InvalidConfigError = InvalidConfigError;
function assertVersion(version) {
    if ((typeof version !== 'bigint' && typeof version !== 'number') ||
        (typeof version === 'number' && !Number.isSafeInteger(version)) ||
        BigInt(version) < 0n ||
        BigInt(version) > exports.maxVersion)
        throw new InvalidConfigError({
            reason: 'version must be an unsigned 64-bit integer',
        });
}
//# sourceMappingURL=MultisigConfig.js.map