"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.InvalidSimulationError = void 0;
exports.fromRpc = fromRpc;
exports.toRpc = toRpc;
const Address = require("../core/Address.js");
const Errors = require("../core/Errors.js");
const Hex = require("../core/Hex.js");
const Rlp = require("../core/Rlp.js");
const MultisigConfig = require("./MultisigConfig.js");
function fromRpc(spec) {
    const { approvals, config } = spec;
    assertApprovals(approvals);
    return { approvals, config: deserializeConfig(config) };
}
function toRpc(spec) {
    const { approvals, config } = spec;
    assertApprovals(approvals);
    return {
        approvals: approvals.map(({ keyData, keyType, owner }) => ({
            ...(keyData !== undefined ? { keyData: shimKeyData(keyData) } : {}),
            ...(keyType !== undefined ? { keyType } : {}),
            owner,
        })),
        config: serializeConfig(config),
    };
}
function assertApprovals(approvals) {
    if (approvals.some((approval) => typeof approval !== 'object' ||
        approval === null ||
        'spec' in approval ||
        'type' in approval))
        throw new InvalidSimulationError({
            reason: 'only untagged primitive owner approvals are allowed',
        });
    if (approvals.length > MultisigConfig.maxSignatures)
        throw new InvalidSimulationError({
            reason: `approval count exceeds ${MultisigConfig.maxSignatures}`,
        });
}
function deserializeConfig(config) {
    const tuple = Rlp.toHex(config);
    if (!Array.isArray(tuple) || tuple.length !== 4)
        throw new InvalidSimulationError({ reason: 'invalid config encoding' });
    const [salt, version, threshold, owners] = tuple;
    if (Array.isArray(salt) ||
        Hex.size(salt) !== 32 ||
        Array.isArray(version) ||
        Hex.size(version) > 8 ||
        (version !== '0x' && Hex.slice(version, 0, 1) === '0x00') ||
        Array.isArray(threshold) ||
        Hex.size(threshold) > 1 ||
        !Array.isArray(owners) ||
        owners.some((owner) => !Array.isArray(owner) ||
            owner.length !== 2 ||
            owner.some(Array.isArray) ||
            !Address.validate(owner[0]) ||
            Hex.size(owner[1]) > 1))
        throw new InvalidSimulationError({ reason: 'invalid config encoding' });
    const value = MultisigConfig.fromTuple(tuple);
    MultisigConfig.assert(value);
    if (!Hex.isEqual(config, serializeConfig(value)))
        throw new InvalidSimulationError({ reason: 'noncanonical config encoding' });
    return value;
}
function serializeConfig(config) {
    return Rlp.fromHex(MultisigConfig.toTuple(config));
}
function shimKeyData(data) {
    const size = Hex.size(data);
    if (size <= 4)
        return data;
    return Hex.fromNumber(size, { size: 2 });
}
class InvalidSimulationError extends Errors.BaseError {
    constructor(options) {
        super(`Invalid multisig simulation: ${options.reason}.`);
        Object.defineProperty(this, "name", {
            enumerable: true,
            configurable: true,
            writable: true,
            value: 'MultisigSimulation.InvalidSimulationError'
        });
    }
}
exports.InvalidSimulationError = InvalidSimulationError;
//# sourceMappingURL=MultisigSimulation.js.map